Kunwar Nir and Hassan Ali worked on this project together. In order to run from the terminal, run test.py

In order to use prebuilt tests, follow the same steps as the automated tests.
